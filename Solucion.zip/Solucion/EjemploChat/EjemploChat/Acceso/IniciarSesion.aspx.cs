using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EjemploChat.Acceso
{
    public partial class IniciarSesion : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UsuarioId"] == null || Session["UsuarioId"].ToString().Trim().Length <= 0)
            {
                if (!IsPostBack)
                {
                    //txtUsuario.Value = Environment.UserName;

                    if (Session["CerrarSesion"] == null && Autenticar() == true)
                        MostrarUsuarioLoggeado();
                    else
                        Session["CerrarSesion"] = null;
                }
            }
            else
            {
                MostrarUsuarioLoggeado();
            }
        }

        private bool? Autenticar()
        {
            BusinessEntity.EjemploChat.dbo.Usuario oUsuarioBE = new BusinessEntity.EjemploChat.dbo.Usuario();
            oUsuarioBE.Correo = txtUsuario.Value;
            oUsuarioBE.Contrase�a = txtContrase�a.Value;

            BusinessEntity.DataHandler oDH = BusinessLogic.Util.Consultar(BusinessEntity.QueryOptions.Consultar_IniciarSesion, oUsuarioBE);

            if (oDH.Error || oDH.ContieneInformacion == false)
            {
                ClientScript.RegisterClientScriptBlock(GetType(), "", "$(function(){Mensaje('La combinaci�n Usuario/Contrase�a no es v�lida.');});", true);
                return false;
            }

            DataRow dr = oDH.Resultado.Tables[0].Rows[0];

            Session["UsuarioId"] = dr["UsuarioId"];
            Session["Usuario"] = dr["Correo"]; 
            Session["Nombre"] = dr["Nombre"];
            Session["NombreCompleto"] = string.Format("{0} {1} {2}", dr["Nombre"], dr["Paterno"], dr["Materno"]);
            Session["Correo"] = dr["Correo"];

            if (dr["Foto"].GetType() != typeof(DBNull))
            {
                //Session["Foto"] = byte;
            }
            else
            {
                Session["Foto"] = null;
            }

			return true;
        }

        private void MostrarUsuarioLoggeado()
        {
            string UrlPrincipal = ConfigurationManager.AppSettings["UrlPrincipal"].ToString();
            Response.Redirect(UrlPrincipal);
        }

        protected void btnIniciarSesion_Click(object sender, EventArgs e)
        {
            if (Autenticar() == true)
            {
                MostrarUsuarioLoggeado();
            }
        }
    }
}