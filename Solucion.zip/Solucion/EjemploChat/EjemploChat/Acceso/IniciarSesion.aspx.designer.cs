//------------------------------------------------------------------------------
// <generado autom�ticamente>
//     Este c�digo fue generado por una herramienta.
//
//     Los cambios en este archivo podr�an causar un comportamiento incorrecto y se perder�n si
//     se vuelve a generar el c�digo. 
// </generado autom�ticamente>
//------------------------------------------------------------------------------

namespace EjemploChat.Acceso {
    
    
    public partial class IniciarSesion {
        
        /// <summary>
        /// Control form1.
        /// </summary>
        /// <remarks>
        /// Campo generado autom�ticamente.
        /// Para modificarlo, mueva la declaraci�n del campo del archivo del dise�ador al archivo de c�digo subyacente.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlForm form1;
        
        /// <summary>
        /// Control txtUsuario.
        /// </summary>
        /// <remarks>
        /// Campo generado autom�ticamente.
        /// Para modificarlo, mueva la declaraci�n del campo del archivo del dise�ador al archivo de c�digo subyacente.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlInputText txtUsuario;
        
        /// <summary>
        /// Control txtContrase�a.
        /// </summary>
        /// <remarks>
        /// Campo generado autom�ticamente.
        /// Para modificarlo, mueva la declaraci�n del campo del archivo del dise�ador al archivo de c�digo subyacente.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlInputPassword txtContrase�a;
        
        /// <summary>
        /// Control btnIniciarSesion.
        /// </summary>
        /// <remarks>
        /// Campo generado autom�ticamente.
        /// Para modificarlo, mueva la declaraci�n del campo del archivo del dise�ador al archivo de c�digo subyacente.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Button btnIniciarSesion;
    }
}
