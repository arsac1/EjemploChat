using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BusinessEntity
{
    public class EntityBase
    {
        public EntityBase()
        {
            FechaCreacion = DateTime.Now;
            FechaModificacion = DateTime.Now;
        }

        public uint UsuarioCreacionId { get; set; }
        public DateTime FechaCreacion { get; set; }
        public uint UsuarioModificacionId { get; set; }
        public DateTime FechaModificacion { get; set; }
        public uint? UsuarioBajaId { get; set; }
        public DateTime? FechaBaja { get; set; }
        public bool? Baja { get; set; }
    }
}
