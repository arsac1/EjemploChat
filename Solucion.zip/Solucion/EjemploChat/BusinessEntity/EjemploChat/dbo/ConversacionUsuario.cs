using System;
using System.Data;

namespace BusinessEntity.EjemploChat.dbo
{
	public class ConversacionUsuario : EntityBase
	{
		public ConversacionUsuario()
		{
		}

		System.Int32 _ConversacionUsuarioId;
		public System.Int32 ConversacionUsuarioId { get { return _ConversacionUsuarioId; } set { if (value >= 0) _ConversacionUsuarioId = value; } }

		System.Int32 _ConversacionId;
		public System.Int32 ConversacionId { get { return _ConversacionId; } set { if (value >= 0) _ConversacionId = value; } }

		System.Int32 _UsuarioId;
		public System.Int32 UsuarioId { get { return _UsuarioId; } set { if (value >= 0) _UsuarioId = value; } }

	}
}