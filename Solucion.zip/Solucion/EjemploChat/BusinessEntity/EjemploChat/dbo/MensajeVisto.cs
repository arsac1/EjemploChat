using System;
using System.Data;

namespace BusinessEntity.EjemploChat.dbo
{
	public class MensajeVisto : EntityBase
	{
		public MensajeVisto()
		{
		}

		System.Int32 _MensajeVistoId;
		public System.Int32 MensajeVistoId { get { return _MensajeVistoId; } set { if (value >= 0) _MensajeVistoId = value; } }

		System.Int32 _MensajeId;
		public System.Int32 MensajeId { get { return _MensajeId; } set { if (value >= 0) _MensajeId = value; } }

	}
}