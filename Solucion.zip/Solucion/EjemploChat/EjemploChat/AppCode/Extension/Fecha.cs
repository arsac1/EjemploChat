using System;
using System.Data;
using System.Globalization;
using System.Web.UI.WebControls;

namespace EjemploChat
{
    public static class Fecha
    {
        /// <summary>
        /// Carga todos los meses del a�o en un DropDownList
        /// </summary>
        /// <param name="NombreCorto">Descripcion del mes</param>
        /// <param name="cbo">DropDownList al que se le asignaran los meses</param>
        public static void CargarMeses(this DropDownList cbo, bool NombreCorto)
        {
            try
            {
                DataTable dt = new DataTable();
                DataColumn[] dc = new DataColumn[2];

                dc[0] = new DataColumn("Id");
                dc[1] = new DataColumn("Descripcion");

                dt.Columns.AddRange(dc);
                dt.Rows.Add("0", "[Seleccionar]");

                for (int i = 1; i < 13; i++)
                {
                    DataRow dr = dt.NewRow();

                    dr["Id"] = i;

                    if (NombreCorto)
                    {
                        //dr["Descripcion"] = Fechas.NombreMesCorto(i);
                    }
                    else
                    {
                        //dr["Descripcion"] = Fechas.NombreMes(i);
                    }

                    dt.Rows.Add(dr);
                }

                cbo.DataValueField = "Id";
                cbo.DataTextField = "Descripcion";
                cbo.DataSource = dt.DefaultView;
            }
            catch
            {
                cbo.DataSource = null;
            }

            cbo.DataBind();
        }

        /// <summary>
        /// Carga desde hace 100 a�os al a�o actual
        /// </summary>
        /// <param name="DropDownList">Combo a llenar</param>
        public static void CargarA�os(this DropDownList cbo)
        {
            int A�oInicial = DateTime.Now.Year - 100;

            cbo.Items.Clear();
            cbo.Items.Add("[A�o]");

            for (int i = DateTime.Now.Year; i >= A�oInicial; i--)
            {
                cbo.Items.Add(i.ToString());
            }
        }

        /// <summary>
        /// Carga rango de a�os
        /// </summary>
        /// <param name="cbo">Combo a llenar</param>
        /// <param name="A�oInicio">A�o de Inicio</param>
        /// <param name="A�oFin">A�o de Fin</param>
        public static void CargarA�os(this DropDownList cbo, int A�oInicio, int A�oFin)
        {
            cbo.Items.Clear();
            cbo.Items.Add("[A�o]");

            for (int i = A�oInicio; i <= A�oFin; i++)
            {
                cbo.Items.Add(i.ToString());
            }
        }

        /// <summary>
        /// Obtiene el nombre del mes a partir del n�mero del mes
        /// </summary>
        /// <param name="MesId">N�mero del mes</param>
        /// <param name="Abreviado">True: Se abrevia a 3 letras</param>
        /// <returns>Nombre del mes</returns>
        public static string NombreMes(this int MesId, bool Abreviado)
        {
            if (MesId >= 1 && MesId <= 12)
            {
                string NombreMes = General.Capitalizar(CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(MesId));
                return (Abreviado) ? NombreMes.Substring(0, 3) : NombreMes;
            }
            else
            {
                return string.Empty;
            }
        }
    }
}