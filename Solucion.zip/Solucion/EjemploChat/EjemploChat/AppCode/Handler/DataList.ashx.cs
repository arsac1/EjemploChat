using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace EjemploChat.AppCode.handler
{
    /// <summary>
    /// Listas de informaci�n por tabla
    /// </summary>
    public class DataList : IHttpHandler
    {
        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "application/json";

            DataTable dt = new DataTable();

            switch (context.Request["Opcion"])
            {
                case "Conversacion": { dt = Conversacion(); break; }
                case "ConversacionUsuario": { dt = ConversacionUsuario(); break; }
                case "Mensaje":
                    {
                        int UsuarioId = 0, UsuarioConversacionId = 0, ConversacionId;
                        int.TryParse(context.Request["UsuarioId"].ToString(), out UsuarioId);
                        int.TryParse(context.Request["UsuarioConversacionId"].ToString(), out UsuarioConversacionId);
                        int.TryParse(context.Request["ConversacionId"].ToString(), out ConversacionId);
                        dt = Mensaje(UsuarioId, UsuarioConversacionId, ConversacionId); break;
                    }
                case "MensajeVisto": { dt = MensajeVisto(); break; }
                case "Usuario":
                    {
                        int UsuarioId = 0;
                        int.TryParse(context.Request["UsuarioId"].ToString(), out UsuarioId);
                        dt = Usuario(UsuarioId); break;
                    }
                default:
                    break;
            }

            string Resultado = "{\"d\":" + BusinessLogic.Util.ConvertDataTabletoString(dt) + "}";

            context.Response.Write(Resultado);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

        public DataTable Conversacion()
        {
            BusinessEntity.EjemploChat.dbo.Conversacion oConversacionBE = new BusinessEntity.EjemploChat.dbo.Conversacion();
            oConversacionBE.Baja = false;

            BusinessEntity.DataHandler oDH = BusinessLogic.Util.Consultar(BusinessEntity.QueryOptions.Consultar_ParaLista, oConversacionBE);

            if (!oDH.Error && oDH.ContieneInformacion)
            {
                return oDH.Resultado.Tables[0];
            }

            return null;
        }

        public DataTable ConversacionUsuario()
        {
            BusinessEntity.EjemploChat.dbo.ConversacionUsuario oConversacionUsuarioBE = new BusinessEntity.EjemploChat.dbo.ConversacionUsuario();
            oConversacionUsuarioBE.Baja = false;

            BusinessEntity.DataHandler oDH = BusinessLogic.Util.Consultar(BusinessEntity.QueryOptions.Consultar_ParaLista, oConversacionUsuarioBE);

            if (!oDH.Error && oDH.ContieneInformacion)
            {
                return oDH.Resultado.Tables[0];
            }

            return null;
        }

        public DataTable Mensaje(int UsuarioId, int UsuarioConversacionId, int ConversacionId)
        {
            BusinessEntity.EjemploChat.dbo.Mensaje oMensajeBE = new BusinessEntity.EjemploChat.dbo.Mensaje();
            oMensajeBE.ConversacionId = ConversacionId;
            oMensajeBE.UsuarioId = UsuarioId;
            oMensajeBE.UsuarioConversacionId = UsuarioConversacionId;
            oMensajeBE.Baja = false;

            BusinessEntity.DataHandler oDH = BusinessLogic.Util.Consultar(BusinessEntity.QueryOptions.Consultar_Mensajes, oMensajeBE);

            if (!oDH.Error && oDH.ContieneInformacion)
            {
                return oDH.Resultado.Tables[oDH.Resultado.Tables.Count - 1];
            }

            return null;
        }

        public DataTable MensajeVisto()
        {
            BusinessEntity.EjemploChat.dbo.MensajeVisto oMensajeVistoBE = new BusinessEntity.EjemploChat.dbo.MensajeVisto();
            oMensajeVistoBE.Baja = false;

            BusinessEntity.DataHandler oDH = BusinessLogic.Util.Consultar(BusinessEntity.QueryOptions.Consultar_ParaLista, oMensajeVistoBE);

            if (!oDH.Error && oDH.ContieneInformacion)
            {
                return oDH.Resultado.Tables[0];
            }

            return null;
        }

        public DataTable Usuario(int UsuarioId)
        {
            BusinessEntity.EjemploChat.dbo.Usuario oUsuarioBE = new BusinessEntity.EjemploChat.dbo.Usuario();
            oUsuarioBE.UsuarioId = UsuarioId;
            oUsuarioBE.Baja = false;

            BusinessEntity.DataHandler oDH = BusinessLogic.Util.Consultar(BusinessEntity.QueryOptions.Consultar_ParaLista, oUsuarioBE);

            if (!oDH.Error && oDH.ContieneInformacion)
            {
                return oDH.Resultado.Tables[0];
            }

            return null;
        }
    }
}