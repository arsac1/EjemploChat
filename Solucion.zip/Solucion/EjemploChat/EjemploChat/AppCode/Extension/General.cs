using System;
using System.Globalization;

namespace EjemploChat
{
    public static class General
    {
        /// <summary>
        /// Guarda registro en Log
        /// </summary>
        /// <param name="str">Datos a guardar</param>
        public static void ToLog(this string str)
        {
            try
            {
                string DirectorioPrincipal = System.Configuration.ConfigurationManager.AppSettings["DirectorioPrincipal"].ToString();
                string RutaLog = DirectorioPrincipal + "temp\\";
                string NombreLog = string.Format("Log_{0}.txt", DateTime.Now.ToString("yyyy-MM"));

                if (!System.IO.Directory.Exists(RutaLog))
                {
                    System.IO.Directory.CreateDirectory(RutaLog);
                }

                using (System.IO.StreamWriter sw = new System.IO.StreamWriter(RutaLog + NombreLog, true))
                {

                    sw.WriteLine(string.Format("{0}\t{1}", DateTime.Now.ToString("yyyy/MM/dd hh:mm:ss"), str));
                }
            }
            catch
            {

            }
        }

        public static string Right(this string str, int Longitud)
        {
            if (String.IsNullOrEmpty(str)) return string.Empty;

            return str.Length <= Longitud ? str : str.Substring(str.Length - Longitud);
        }

        public static string Capitalizar(string str)
        {
            if (str == null)
                return null;

            if (str.Trim().Length == 0)
                return str;

            return CultureInfo.CurrentCulture.TextInfo.ToTitleCase(str.ToLower());
        }
    }
}