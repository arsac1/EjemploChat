using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EjemploChat.inc.master
{
    public partial class Principal : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int UsuarioId = 0;
            string UrlPrincipal = System.Configuration.ConfigurationManager.AppSettings["UrlPrincipal"].ToString();
            hdnUrlPrincipal.Value = UrlPrincipal;

            if (Session["UsuarioId"] == null /*Existe la variable de sesi�n*/
                || Session["UsuarioId"].ToString().Trim().Length == 0 /*La variable de sesi�n tiene asignado alg�n valor*/
                || !int.TryParse(Session["UsuarioId"].ToString(), out UsuarioId)/*El valor asignado a la variable de sesi�n es num�rico*/
                || UsuarioId <= 0 /*El valor num�rico es mayor a cero*/)
            {
                string Login = UrlPrincipal + "Acceso/IniciarSesion.aspx";
                Response.Redirect(Login);
            }
            else
            {
                txtNombreUsuario.Text = Session["NombreCompleto"].ToString();
                hdnUsuarioId.Value = Session["UsuarioId"].ToString();

                if (Session["Foto"] != null)
                {
                    imgFoto.ImageUrl = "data:image/jpg;base64," + Convert.ToBase64String((byte[])Session["Foto"]);
                }
                else
                {
                    imgFoto.ImageUrl = UrlPrincipal + "img/ProfilePictureless.png";
                }
            }
        }
    }
}