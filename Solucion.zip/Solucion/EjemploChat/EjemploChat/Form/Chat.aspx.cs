﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EjemploChat.Form
{
    public partial class Chat : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        [WebMethod]
        public static string EnviarMensaje(int ConversacionId, string MensajeDescripcion, string AdjuntoNombre, int UsuarioId)
        {
            BusinessEntity.EjemploChat.dbo.Mensaje oMensajeBE = new BusinessEntity.EjemploChat.dbo.Mensaje();

            #region Cargar Parámetros
            oMensajeBE.ConversacionId = ConversacionId;
            oMensajeBE.MensajeDescripcion = MensajeDescripcion;
            oMensajeBE.AdjuntoNombre = AdjuntoNombre;

            oMensajeBE.UsuarioCreacionId = (uint)UsuarioId;
            oMensajeBE.FechaCreacion = DateTime.Now;
            oMensajeBE.UsuarioModificacionId = (uint)UsuarioId;
            oMensajeBE.FechaModificacion = DateTime.Now;
            oMensajeBE.Baja = false;
            #endregion

            #region Enviar consulta
            BusinessEntity.DataHandler oDH = BusinessLogic.Util.Insertar(BusinessEntity.QueryOptions.Insertar_General, oMensajeBE);
            #endregion

            #region Valida Errores
            if (oDH.Error || !oDH.ContieneInformacion)
            {
                return oDH.MensajeError;
            }
            #endregion

            return BusinessLogic.Util.ConvertDataTabletoString(oDH.Resultado.Tables[0]);
        }
    }
}