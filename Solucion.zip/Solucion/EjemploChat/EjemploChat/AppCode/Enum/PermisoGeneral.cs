using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EjemploChat
{
    public enum PermisoGeneral
    {
        AGREGAR = 7,
        BUSCAR = 2,
        CANCELAR = 14,
        CARGAR_ARCHIVO = 11,
        Default = 0,
        DESCARGAR = 10,
        EDITAR = 4,
        ELIMINAR = 6,
        ENVIAR = 13,
        EXPORTAR = 9,
        GUARDAR = 3,
        IMPORTAR = 15,
        IMPRIMIR = 12,
        LIMPIAR = 5,
        PROCESAR = 8,
        VISUALIZAR = 1,
        AUTORIZAR = 16,
        DECLINAR = 17
    }
}