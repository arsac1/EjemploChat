﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic
{
    public static class Correo
    {
        public static bool Enviar(MailMessage Mensaje)
        {
            try
            {
                NameValueCollection CorreoSettings = (NameValueCollection)ConfigurationManager.GetSection("CorreoSettings");

                SmtpClient smtp = new SmtpClient();
                smtp.Host = CorreoSettings["ServidorSMTP"].ToString();
                smtp.EnableSsl = true;
                NetworkCredential NetworkCred = new NetworkCredential(CorreoSettings["Usuario"].ToString(), CorreoSettings["Contraseña"].ToString());
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = NetworkCred;
                smtp.Port = Convert.ToInt32(CorreoSettings["Puerto"]);
                smtp.Send(Mensaje);

                return true;
            }
            catch
            {

            }

            return false;
        }
    }
}
