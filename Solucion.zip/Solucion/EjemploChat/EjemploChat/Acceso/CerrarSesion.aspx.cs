using System;

namespace EjemploChat.Acceso
{
    public partial class CerrarSesion : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Session.RemoveAll();

            Session["CerrarSesion"] = true;
            Response.Redirect("../Principal.aspx");
        }
    }
}