using System;
using System.Collections.Generic;
using System.Data;

namespace BusinessLogic
{
	internal static class MapaClases
	{
		internal static dynamic EntityToData(object oBE)
		{
			Dictionary<object, object> BusinessDataList = new Dictionary<object, object>();

			BusinessDataList.Add(typeof(BusinessEntity.EjemploChat.dbo.Conversacion), typeof(BusinessData.EjemploChat.dbo.Conversacion));
			BusinessDataList.Add(typeof(BusinessEntity.EjemploChat.dbo.ConversacionUsuario), typeof(BusinessData.EjemploChat.dbo.ConversacionUsuario));
			BusinessDataList.Add(typeof(BusinessEntity.EjemploChat.dbo.Mensaje), typeof(BusinessData.EjemploChat.dbo.Mensaje));
			BusinessDataList.Add(typeof(BusinessEntity.EjemploChat.dbo.MensajeVisto), typeof(BusinessData.EjemploChat.dbo.MensajeVisto));
			BusinessDataList.Add(typeof(BusinessEntity.EjemploChat.dbo.Usuario), typeof(BusinessData.EjemploChat.dbo.Usuario));
			dynamic valor;

			if (BusinessDataList.TryGetValue(oBE.GetType(), out valor))
			{
				return valor;
			}

			return typeof(object);
		}
	}
}