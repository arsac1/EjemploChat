using System.Collections.Generic;
using System.Data;

namespace EjemploChat
{
    public static class Util
    {
    }
}