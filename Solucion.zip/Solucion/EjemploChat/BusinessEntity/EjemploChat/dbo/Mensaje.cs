using System;
using System.Data;

namespace BusinessEntity.EjemploChat.dbo
{
	public class Mensaje : EntityBase
	{
		public Mensaje()
		{
			_MensajeDescripcion = string.Empty;
			_AdjuntoNombre = string.Empty;
		}

		System.Int32 _MensajeId;
		public System.Int32 MensajeId { get { return _MensajeId; } set { if (value >= 0) _MensajeId = value; } }

		System.Int32 _ConversacionId;
		public System.Int32 ConversacionId { get { return _ConversacionId; } set { if (value >= 0) _ConversacionId = value; } }

		System.String _MensajeDescripcion;
		public System.String MensajeDescripcion { get { return _MensajeDescripcion; } set { if (value.Length >= 8000) _MensajeDescripcion = value.Substring(0, 8000); else _MensajeDescripcion = value; } }

		System.String _AdjuntoNombre;
		public System.String AdjuntoNombre { get { return _AdjuntoNombre; } set { if (value.Length >= 8000) _AdjuntoNombre = value.Substring(0, 8000); else _AdjuntoNombre = value; } }


        public int UsuarioId { get; set; }

        public int UsuarioConversacionId { get; set; }
    }
}