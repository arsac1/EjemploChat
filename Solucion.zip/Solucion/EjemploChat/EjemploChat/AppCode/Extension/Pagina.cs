using System.Web.UI;

namespace EjemploChat
{
    public static class Pagina
    {
        /// <summary>
        /// Redirige a la pagina principal
        /// </summary>
        /// <param name="pagina">Pagina original</param>
        public static void Salir(this Page pagina)
        {
            string UrlPrincipal = System.Configuration.ConfigurationManager.AppSettings["UrlPrincipal"].ToString() + "Acceso/IniciarSesion.aspx";

            pagina.ClientScript.RegisterClientScriptBlock(pagina.GetType(), "", "window.open('" + UrlPrincipal + "', target='_top');", true);
        }

        /// <summary>
        /// Redirige a p�gina principal mostrando un mensaje previo
        /// </summary>
        /// <param name="pagina">pagina actual</param>
        /// <param name="Mensaje">Mensaje a mostrar</param>
        /// 
        public static void Salir(this Page pagina, string Mensaje)
        {
            string UrlPrincipal = System.Configuration.ConfigurationManager.AppSettings["UrlPrincipal"].ToString();
            pagina.ClientScript.RegisterClientScriptBlock(pagina.GetType(), "", "alert('" + Mensaje + "');window.open('" + UrlPrincipal + "', target='_top');", true);

            //UrlPrincipal += string.Format("inc/site/Mensaje.aspx?Mensaje={0}&MensajeTipoId={1}", Mensaje, 2);
            //pagina.ClientScript.RegisterClientScriptBlock(pagina.GetType(), "", "window.open('" + UrlPrincipal + "', target='main');", true);
        }

        public static void EjecutarJavaScript(this Page pagina, string codigoJavaScript)
        {
            string Script = "$(document).ready(function() { " + codigoJavaScript + " });";
            pagina.ClientScript.RegisterClientScriptBlock(pagina.GetType(), "", Script, true);
        }
    }
}