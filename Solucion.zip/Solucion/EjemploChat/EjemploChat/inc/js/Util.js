﻿function RunAjax(varUrl, varData) {
    var res;

    $.ajax({
        type: "POST",
        url: varUrl,
        data: varData,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: false,
        cache: false,
        success: function (response) {
            res = response.d;
        },
        failure: function (response) {
            alert("Failure: " + response.d);
        },
        error: function (XMLHttpRequest, success, errorThrown) {
            alert("Error" + XMLHttpRequest.responseText + ' ' + errorThrown)
        }
    });

    return res;
}

function QueryString(name) {
    var url = location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

var NombreMeses = [
  "Enero", "Febrero", "Marzo",
  "Abril", "Mayo", "Junio", "Julio",
  "Agosto", "Septiembre", "Octubre",
  "Noviembre", "Diciembre"
];

function FormatoFechaHora(Fecha) {
    var date = [];
    if (Fecha instanceof Date) {
        date = Fecha;
    }
    else {
        date = new Date(parseInt(Fecha.substr(6)));
    }

    var day = date.getDate();
    var monthIndex = date.getMonth();
    var year = date.getFullYear();
    var hour = date.getHours();
    var minute = date.getMinutes();

    return ("0" + day).substr(-2) + '-' + NombreMeses[monthIndex].substr(0, 3) + '-' + year + ' ' + ("0" + hour).substr(-2) + ':' + ("0" + minute).substr(-2);
}