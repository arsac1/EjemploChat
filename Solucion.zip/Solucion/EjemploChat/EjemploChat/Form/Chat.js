﻿var Notificador = [];
$(function () {
    CargarUsuarios();

    // Initialize the connection to the server
    Notificador = $.connection.notificadorHub;

    // Preparing a client side function called sendMessage that will be called from the server side
    Notificador.client.difundirMensaje = function (ConversacionId) {
        if (ConversacionId == $("#hdnConversacionId").val()) {
            CargarMensajes(ConversacionId, 0);
        }
    };

    // Establish the connection to the server. When done, sets the click of the button
    $.connection.hub.start().done(function () {
        $('#txtMensaje').keyup(function (e) {
            if (e.keyCode == 13) {
                EnviarMensaje();
            }
        });
    });
});

function CargarUsuarios() {
    var Url = UrlPrincipal + "AppCode/Handler/DataList.ashx?Opcion=Usuario&UsuarioId=" + UsuarioId;
    var resultado = RunAjax(Url, "");

    $("#dvUsuarios").html("");
    
    if (resultado != undefined && resultado != null) {
        var source = $("#hbtUsuarios").html();
        var template = Handlebars.compile(source);
        var ResultadoHTML = template(resultado);

        $("#dvUsuarios").html(ResultadoHTML);
    }
}

function CargarMensajes(ConversacionId, UsuarioConversacionId) {
    $("#hdnUsuarioConversacionId").val(UsuarioConversacionId);
    var Url = UrlPrincipal + "AppCode/Handler/DataList.ashx?Opcion=Mensaje&UsuarioId=" + UsuarioId + "&UsuarioConversacionId=" + UsuarioConversacionId + "&ConversacionId=" + ConversacionId;
    var resultado = RunAjax(Url, "");

    $("#dvMensajes").html("");

    if (resultado != undefined && resultado != null && resultado.length > 0) {
        $("#hdnConversacionId").val(resultado[0].ConversacionId);

        $.map(resultado, function (a) {
            a.FechaMostrar = FormatoFechaHora(a.FechaCreacion);
        });

        var source = $("#hbtMensajes").html();
        var template = Handlebars.compile(source);
        var ResultadoHTML = template(resultado);

        $("#dvMensajes").html(ResultadoHTML);
    }
    else {
        $("#dvMensajes").html("<div class='jumbotron'><h3>Parece que no has hablado con este usuario, intenta decir ¡Hola!</h3></div>.");
    }

    $("#dvMensajes").animate({ scrollTop: $('#dvMensajes').prop("scrollHeight") }, 1000);
}

function EnviarMensaje() {
    var ConversacionId = $("#hdnConversacionId").val();

    if (isNaN(ConversacionId) || ConversacionId <= 0) {
        toastr.warning("Por favor selecciona una conversación para poder enviar un mensaje.");
        return;
    }

    var Url = "Chat.aspx/EnviarMensaje";
    var Parametros = {
        ConversacionId: ConversacionId,
        MensajeDescripcion: $("#txtMensaje").val(),
        AdjuntoNombre: "",
        UsuarioId: UsuarioId
    };

    var resultado = RunAjax(Url, JSON.stringify(Parametros));

    if (resultado != undefined && resultado != null && resultado.length > 0) {
        $("#txtMensaje").val("").focus();
        toastr.success("Mensaje enviado exitosamente.");
        //CargarMensajes(ConversacionId, $("#hdnUsuarioConversacionId").val());
        Notificador.server.enviarMensaje(ConversacionId);
    }
    else {
        toastr.warning("Lo sentimos, tu mensaje no pudo ser enviado. Por favor intenta actualizando la página (F5).");
    }
}