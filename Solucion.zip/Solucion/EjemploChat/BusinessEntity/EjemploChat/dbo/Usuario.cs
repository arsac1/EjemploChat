using System;
using System.Data;

namespace BusinessEntity.EjemploChat.dbo
{
	public class Usuario : EntityBase
	{
		public Usuario()
		{
			_Correo = string.Empty;
			_Contrase�a = string.Empty;
			_Nombre = string.Empty;
			_Paterno = string.Empty;
			_Materno = string.Empty;
		}

		System.Int32 _UsuarioId;
		public System.Int32 UsuarioId { get { return _UsuarioId; } set { if (value >= 0) _UsuarioId = value; } }

		System.String _Correo;
		public System.String Correo { get { return _Correo; } set { if (value.Length >= 500) _Correo = value.Substring(0, 500); else _Correo = value; } }

		System.String _Contrase�a;
		public System.String Contrase�a { get { return _Contrase�a; } set { if (value.Length >= 100) _Contrase�a = value.Substring(0, 100); else _Contrase�a = value; } }

		System.String _Nombre;
		public System.String Nombre { get { return _Nombre; } set { if (value.Length >= 500) _Nombre = value.Substring(0, 500); else _Nombre = value; } }

		System.String _Paterno;
		public System.String Paterno { get { return _Paterno; } set { if (value.Length >= 500) _Paterno = value.Substring(0, 500); else _Paterno = value; } }

		System.String _Materno;
		public System.String Materno { get { return _Materno; } set { if (value.Length >= 500) _Materno = value.Substring(0, 500); else _Materno = value; } }

		System.Byte[] _Foto;
		public System.Byte[] Foto { get { return _Foto; } set { _Foto = value; } }

	}
}