using System;
using System.Data;

namespace BusinessEntity.EjemploChat.dbo
{
	public class Conversacion : EntityBase
	{
		public Conversacion()
		{
			_ConversacionDescripcion = string.Empty;
		}

		System.Int32 _ConversacionId;
		public System.Int32 ConversacionId { get { return _ConversacionId; } set { if (value >= 0) _ConversacionId = value; } }

		System.String _ConversacionDescripcion;
		public System.String ConversacionDescripcion { get { return _ConversacionDescripcion; } set { if (value.Length >= 500) _ConversacionDescripcion = value.Substring(0, 500); else _ConversacionDescripcion = value; } }

		System.Byte[] _Foto;
		public System.Byte[] Foto { get { return _Foto; } set { _Foto = value; } }

	}
}