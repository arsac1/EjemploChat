using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;

namespace WebTemplate
{
    public class Global : System.Web.HttpApplication
    {
        #region Default
        protected void Application_Start(object sender, EventArgs e)
        {

        }

        protected void Session_Start(object sender, EventArgs e)
        {

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }
        #endregion

        protected void Application_Error(object sender, EventArgs e)
        {
            return;
            // Este archivo requiere para funcionar las siguientes variables:
            //     <add key="UrlPrincipal"              value="http://localhost:4445/KioscoHCN/" />
            //     <add key="DirectorioPrincipal"       value="C:\Proyectos\Nova\HCN\KioscoHCN\Kiosco\"/>
            //     <add key="GlobalError.MostrarCodigo" value="0" /> <!--1:true, 0:false-->
            //     <add key="GlobalError.EnviarCorreo"  value="1" /> <!--1:true, 0:false-->
            //     <add key="GlobalError.CorreoPara"    value="omedina@novaservicios.com.mx" />
            NameValueCollection GlobalErrorSettings = (NameValueCollection)ConfigurationManager.GetSection("GlobalErrorSettings");
            try
            {
                string sHome = System.Configuration.ConfigurationManager.AppSettings["UrlPrincipal"].ToString();

                string sMostrarCodigo = string.Empty;
                if (GlobalErrorSettings["MostrarCodigo"] == null)
                    return;
                else
                    sMostrarCodigo = GlobalErrorSettings["MostrarCodigo"].ToString();


                // Code that runs when an unhandled error occurs

                // Get the exception object.
                Exception exc = Server.GetLastError();

                // Handle HTTP errors
                if (exc.GetType() == typeof(HttpException))
                {
                    // The Complete Error Handling Example generates
                    // some errors using URLs with "NoCatch" in them;
                    // ignore these here to simulate what would happen
                    // if a global.asax handler were not implemented.
                    if (exc.Message.Contains("NoCatch") || exc.Message.Contains("maxUrlLength"))
                        return;

                    //Redirect HTTP errors to HttpError page
                    //Server.Transfer(sHome + "include/ErrorPages/Http404.aspx");
                    string sUrl404 = string.Empty;
                    sUrl404 = sHome + "inc/Mensaje.aspx";
                    sUrl404 += "?Tipo=3";
                    sUrl404 += "&Titulo=Error 404.";
                    sUrl404 += "&Mensaje=Recurso no encontrado.";
                    sUrl404 += "&Redireccion=Default.aspx";
                    Response.Redirect(sUrl404, true);
                }

                string sSession = string.Empty;
                if (exc.GetType() != typeof(HttpCompileException))
                {
                    for (int i = 0; i < Session.Count; i++)
                    {
                        sSession += Session.Keys[i].ToString() + "=" + Session.Contents[i].ToString() + ", ";
                    }
                }

                string sQueryString = string.Empty;
                for (int i = 0; i < Request.QueryString.Count; i++)
                {
                    sQueryString += Request.QueryString.Keys[i].ToString() + "=" + Request.QueryString[i].ToString() + ", ";
                }


                string mensajeLog = DateTime.Now.ToString("dd-MMM-yyyy HH:mm:ss");
                mensajeLog +=
                    "\r\nMessage: " + exc.Message +
                    "\r\nInnerException: " + exc.InnerException +
                    "\r\nPageReferrer: " + Request.UrlReferrer +
                    "\r\nSession: " + sSession +
                    "\r\nQueryString: " + sQueryString +
                    "\r\nData: " + exc.Data.ToString() +
                    "\r\nHelpLink: " + exc.HelpLink +
                    "\r\nSource: " + exc.Source +
                    "\r\nStackTrace: " + exc.StackTrace +
                    "\r\nTargetSite: " + exc.TargetSite +
                    "\r\nGetType: " + exc.GetType().ToString() +
                    "\r\n\r\n\r\n";


                string sPathName = System.Configuration.ConfigurationManager.AppSettings["DirectorioPrincipal"].ToString();

                if (!System.IO.Directory.Exists(sPathName + "temp\\"))
                {
                    System.IO.Directory.CreateDirectory(sPathName + "temp");
                }

                string sYear = DateTime.Now.Year.ToString();
                string sMonth = DateTime.Now.Month.ToString("00");
                StreamWriter sw = new StreamWriter(sPathName + "\\temp\\Log-Error_" + sYear + "-" + sMonth + ".txt", true);
                sw.WriteLine(mensajeLog);
                sw.Flush();
                sw.Close();


                //bool bEnviado = EnviarCorreoError(exc.Message.ToString(), exc.InnerException.ToString());
                string sMessage = string.Empty;
                string sInnerException = string.Empty;
                if (exc.GetType() == typeof(HttpCompileException))
                {
                    sMessage = exc.Message.ToString();
                    //sInnerException = ""; //InnerException isn't available in Exception class.
                }
                else
                {
                    sMessage = exc.Message.ToString();
                    sInnerException = exc.InnerException.ToString();
                }
                EnviarCorreoError(sMessage, sInnerException);

                // Clear the error from the server
                Server.ClearError();

                if (sMostrarCodigo == "0")
                {
                    string sUrl = string.Empty;
                    sUrl = sHome + "include/Mensaje.aspx";
                    sUrl += "?Tipo=2";
                    sUrl += "&Titulo=Error.";
                    sUrl += "&Mensaje=Ha ocurrido un error al procesar su petici�n. Por favor rep�rtalo al administrador.";
                    sUrl += "&Redireccion=Default.aspx";
                    Response.Redirect(sUrl, true);
                }
                else
                {
                    mensajeLog = "<b>" + DateTime.Now.ToString("dd-MMM-yyyy HH:mm:ss") + "</b>";
                    mensajeLog +=
                        "<br /><br /><b>Message:</b><br />" + exc.Message +
                        "<br /><br /><b>InnerException:</b><br />" + exc.InnerException +
                        "<br /><br /><b>PageReferrer:</b><br />" + Request.UrlReferrer +
                        "<br /><br /><b>Session:</b><br />" + sSession +
                        "<br /><br /><b>QueryString:</b><br />" + sQueryString +
                        "<br /><br /><b>Data:</b><br />" + exc.Data.ToString() +
                        "<br /><br /><b>HelpLink:</b><br />" + exc.HelpLink +
                        "<br /><br /><b>Source:</b><br />" + exc.Source +
                        "<br /><br /><b>StackTrace:</b><br />" + exc.StackTrace +
                        "<br /><br /><b>TargetSite:</b><br />" + exc.TargetSite +
                        "<br /><br /><b>GetType:</b><br />" + exc.GetType().ToString() +
                        "<br /><br /><br />";

                    Response.Write("<h2 style='font-family: Calibri, Arial; font-size: 18px;'>Page Error</h2>\n");
                    Response.Write("<p style='font-family: Calibri, Arial; font-size: 12px;'>" + mensajeLog + "</p>\n");
                }
            }
            catch (Exception ex)
            {
                try
                {
                    string sHome = System.Configuration.ConfigurationManager.AppSettings["UrlPrincipal"].ToString();

                    Response.Write("<h2>Global Page Error</h2>\n");
                    Response.Write(
                        "<p>" + ex.Message + "</p>\n");
                    Response.Write("Return to the <a href='" + sHome + "Default.aspx'>" +
                        "Default Page</a>\n");
                    Response.End();
                }
                catch
                {

                }
            }

        }

        public bool EnviarCorreoError(string pMessage, string pInnerException)
        {
            NameValueCollection GlobalErrorSettings = (NameValueCollection)ConfigurationManager.GetSection("GlobalErrorSettings");
            bool EnviarCorreo = false;
            string CorreoPara = string.Empty;

            if (GlobalErrorSettings["EnviarCorreo"] != null && GlobalErrorSettings["CorreoPara"] != null)
            {
                EnviarCorreo = (GlobalErrorSettings["EnviarCorreo"].ToString() == "1");

                if (EnviarCorreo)
                {
                    NameValueCollection CorreoSettings = (NameValueCollection)ConfigurationManager.GetSection("CorreoSettings");
                    MailMessage Email = new MailMessage();
                    string NombreAplicacion = System.Configuration.ConfigurationManager.AppSettings["NombreAplicacion"].ToString();

                    Email.From = new MailAddress(string.Format("{0} <no-reply@ternium.com.mx>", NombreAplicacion));

                    CorreoPara = GlobalErrorSettings["CorreoPara"].ToString();
                    Email.To.Add(new MailAddress(CorreoPara));

                    Email.Subject = "Error de c�digo";

                    Email.IsBodyHtml = true;
                    Email.Priority = MailPriority.Normal;


                    string sBody = "<div style=\"font-family:Verdana;font-size:11px;\">";
                    sBody += "<b>" + NombreAplicacion + ": Error de c�digo</b><br /><br />";
                    sBody += "Fecha: " + DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss") + "<br /><br />";
                    sBody += "Mensaje: " + pMessage + "<br />";
                    sBody += "Error: " + pInnerException + "<br />";
                    sBody += "</div>";

                    Email.Body = sBody;

                    string sSmtpServer = CorreoSettings["ServidorSMTP"].ToString();
                    SmtpClient smtp = new SmtpClient(sSmtpServer);

                    try
                    {
                        smtp.Send(Email);
                        Email = null;
                        return true;
                    }
                    catch (System.Exception)
                    {
                        Email = null;
                        return false;
                    }

                }
            }
            return true;
        }
    }
}