using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BusinessEntity
{
    public enum QueryOptions
    {
        Consultar_PorId = 1,
        Consultar_PorFiltrosGenerales = 2,
        Consultar_ParaLista = 3,
        Consultar_IniciarSesion = 4,
        Consultar_Mensajes = 4,
        Consultar_Contrase�aPorCorreo = 5,

        Insertar_General = 1,

        Actualizar_RegistroCompleto = 1,
        Actualizar_Baja = 2
    }
}
