using System.Linq;
using System.Web;
using System.Web.UI;

namespace EjemploChat
{
    public static class Permiso
    {
        /// <summary>
        /// Redirige a p�gina principal mostrando un mensaje previo
        /// </summary>
        /// <param name="pagina">pagina actual</param>
        /// <param name="Mensaje">Mensaje a mostrar</param>
        public static void SalirModalMensaje(this Page pagina, string RegresarA)
        {
            string UrlPrincipal = System.Configuration.ConfigurationManager.AppSettings["UrlPrincipal"].ToString();

            pagina.Response.Write("<script language='javascript'>alert('Lo sentimos, no tienes privilegios para ejecutar esta operaci�n.'); location.href='" + RegresarA + "'</script>");
            //string Mensaje = "Lo sentimos, no tienes privilegios para ejecutar esta operaci�n.";
            //UrlPrincipal += string.Format("inc/site/Mensaje.aspx?Mensaje={0}&MensajeTipoId={1}&UrlRegreso={2}{3}", Mensaje, 2, UrlPrincipal, RegresarA);
            //pagina.ClientScript.RegisterClientScriptBlock(pagina.GetType(), "", "window.open('" + UrlPrincipal + "', target='main');", true);
        }

        public static bool PermisoValido(this Page pagina, int AplicacionId, PermisoGeneral permiso)
        {
            try
            {
                System.Data.DataTable dtPermisos = HttpContext.Current.Session["Permisos"] as System.Data.DataTable;

                if (dtPermisos != null)
                {
                    string Filtro = string.Format("AplicacionId = {0} AND ProcesoGeneralId = {1}", AplicacionId, (int)permiso);
                    System.Data.DataRow drResultado = dtPermisos.Select(Filtro).FirstOrDefault();

                    if (drResultado != null)
                    {
                        return true;
                    }
                }
            }
            catch
            {

            }

            return false;
        }

        public static bool PermisoValidoModal(this Page pagina, int AplicacionId, PermisoGeneral permiso, string RegresarA)
        {
            try
            {
                System.Data.DataTable dtPermisos = HttpContext.Current.Session["Permisos"] as System.Data.DataTable;

                if (dtPermisos != null)
                {
                    string Filtro = string.Format("AplicacionId = {0} AND ProcesoGeneralId = {1}", AplicacionId, (int)permiso);
                    System.Data.DataRow drResultado = dtPermisos.Select(Filtro).FirstOrDefault();

                    if (drResultado != null)
                    {
                        return true;
                    }
                }
            }
            catch
            {

            }

            SalirModalMensaje(pagina, RegresarA);
            return false;
        }

        /// <summary>
        /// Valida que al menos 1 permiso sea v�lido
        /// </summary>
        /// <param name="pagina">Pagina que validar�</param>
        /// <param name="AplicacionId">Id de la aplicacion</param>
        /// <param name="Permisos">Permiso general</param>
        /// <returns>Verdadero si existe y falso si no</returns>
        public static bool PermisoValido(this Page pagina, int AplicacionId, params PermisoGeneral[] Permisos)
        {
            try
            {
                System.Data.DataTable dtPermisos = HttpContext.Current.Session["Permisos"] as System.Data.DataTable;

                if (dtPermisos != null)
                {
                    foreach (PermisoGeneral permiso in Permisos)
                    {
                        string Filtro = string.Format("AplicacionId = {0} AND ProcesoGeneralId = {1}", AplicacionId, (int)permiso);
                        System.Data.DataRow drResultado = dtPermisos.Select(Filtro).FirstOrDefault();

                        if (drResultado != null)
                        {
                            return true;
                        }
                    }
                }
            }
            catch
            {

            }

            return false;
        }

        public static bool PermisoValidoMensaje(this Page pagina, int AplicacionId, PermisoGeneral permiso)
        {
            try
            {
                System.Data.DataTable dtPermisos = HttpContext.Current.Session["Permisos"] as System.Data.DataTable;

                if (dtPermisos != null)
                {
                    string Filtro = string.Format("AplicacionId = {0} AND ProcesoGeneralId = {1}", AplicacionId, (int)permiso);
                    System.Data.DataRow drResultado = dtPermisos.Select(Filtro).FirstOrDefault();

                    if (drResultado != null)
                    {
                        return true;
                    }
                }
            }
            catch
            {

            }

            pagina.Salir("Lo sentimos, no tienes privilegios para ejecutar esta operaci�n.");
            return false;
        }
    }
}