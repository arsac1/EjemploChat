using System;
using System.Data;
using System.Data.Odbc;
using System.Configuration;

namespace BusinessData.Conexion
{
	public class ConexionODBC
	{
		public string NombreConexion = "cxn";
		public OdbcConnection oConexion = new OdbcConnection();
		public OdbcCommand oComando;
		public OdbcParameter oParametro;
		public OdbcDataAdapter oAdaptador;

		public ConexionODBC()
		{
			oComando = new OdbcCommand();
		}

		public bool Conectar()
		{
			oConexion.ConnectionString = ConfigurationManager.ConnectionStrings[NombreConexion].ConnectionString;

			if (oConexion.State == ConnectionState.Closed)
			{
				try
				{
					oConexion.Open();
					oComando.Connection = oConexion;
					return true;
				}
				catch
				{

				}
			}

			return false;
		}

		public void Desconectar()
		{
			try
			{
				oConexion.Close();
			}
			catch
			{

			}
		}
	}
}