﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EjemploChat.Acceso
{
    public partial class Registro : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnRegistrarse_Click(object sender, EventArgs e)
        {
            BusinessEntity.EjemploChat.dbo.Usuario oUsuarioBE = new BusinessEntity.EjemploChat.dbo.Usuario();
            oUsuarioBE.Nombre = txtNombre.Value;
            oUsuarioBE.Correo = txtCorreo.Value;
            oUsuarioBE.Contraseña = txtContraseña.Value;

            BusinessEntity.DataHandler oDH = BusinessLogic.Util.Insertar(BusinessEntity.QueryOptions.Insertar_General, oUsuarioBE);

            if (oDH.Error || !oDH.ContieneInformacion)
            {
                Mensaje("No se pudo registrar correctamente");
            }

            Mensaje("Usuario creado correctamente.");
        }

        public void Mensaje(string msj)
        {
            ClientScript.RegisterClientScriptBlock(GetType(), "", "$(function(){toastr.info('" + msj + "')});", true);
        }
    }
}